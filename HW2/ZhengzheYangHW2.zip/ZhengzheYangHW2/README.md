To compile: 
javac c45.java
javac bayes.java

To run: 
java c45 [INPUT_FILE_NAME] [TEST_FILE_NAME] [OUTPUT_FILE_NAME]
java bayes [INPUT_FILE_NAME] [TEST_FILE_NAME] [OUTPUT_FILE_NAME]

